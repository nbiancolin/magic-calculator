#ifndef calculator_h
#define calculator_h

void calc(stringstream &ss);

#endif //calculator_h