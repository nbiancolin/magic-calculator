#ifndef processInput_h
#define processInput_h

int processInput(std::string &input, int &i);
void hint(int i);
std::string tolower(string &str);

#endif